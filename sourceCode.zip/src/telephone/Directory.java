package telephone;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
interface Directory
{
	
	public default String getNumber()
	{
		//Call Directory
		Map<String, String> dir= new HashMap<String, String>();
		dir.put("Abcd", "9090909090");
		dir.put("Bcde", "9090909091");
		dir.put("Cbae", "9090909092");
		dir.put("Deab", "9090909093");
		String res=null;
		//Select a number from Directory
		Iterator it = dir.entrySet().iterator();
		System.out.println("Name\tNumber");
		while(it.hasNext())
		{
			Map.Entry m = (Map.Entry)it.next();
			System.out.println(m.getKey()+"\t"+m.getValue());
		}
		System.out.println("Dial a number from above list: ");
		//Dial a number from directory provided
		Scanner sc1 = new Scanner(System.in);
		res = sc1.next();
		
		return res;
	}
}