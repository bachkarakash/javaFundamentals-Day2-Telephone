package telephone;

import java.util.Scanner;

public class Telephone extends User implements Directory
{
	String keypad;
	Telephone(String name, String number,int age)
	{
		super(name,number,age);
	}
	public void receive()
	{
		Scanner sc1 = new Scanner(System.in);
		long number1 = (long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L;
		String number2 = Long.toString(number1);
		System.out.println("Incoming Call from: "+number2);
		System.out.println("Your call is connected");
		System.out.println("press '0' to end call");
		sc1.nextInt();
		this.updateHistory(number2);
	}
	//Make a call
	public void call()
	{
		int choice;
		boolean res;
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Menu:\n1) Dial\n2) Redial from history\n3) Select from Directory");
		choice = sc1.nextInt();
		switch(choice)
		{
		case 1:
			//Dial a number
			System.out.println("Dial the number");
			keypad=null;
			keypad = sc1.next();
			//Validate the number
			if(keypad.length()!=10)
			{
				System.out.println("Number is incorrect");
				break;
			}
			System.out.println("Your call is connected");
			//Update call history
			this.updateHistory(keypad);
			System.out.println("press '0' to end call");
			sc1.nextInt();
			break;
		case 2:
			//Select a number to call from call history
			keypad=null;
			res=super.checkHistory();
			if(res==false)
			{
				break;
			}
			System.out.println("Dial a number from above list: ");
			keypad = sc1.next();
			while(keypad.length()!=10)
			{
				System.out.println("Invalid Number!! Please enter correct number");
				keypad = sc1.next();
			}
			System.out.println("Your call is connected");
			this.updateHistory(keypad);
			System.out.println("press '0' to end call");
			sc1.nextInt();
			break;
		case 3:
			//Select a number from directory
			keypad = this.getNumber().toString();
			while(keypad.length()!=10)
			{
				System.out.println("Invalid Number!! Please enter correct number");
				keypad = sc1.next();
			}
			System.out.println("Your call is connected");
			this.updateHistory(keypad);
			System.out.println("press '0' to end call");
			sc1.nextInt();
			break;
		}
	}
	//Check call history
	public boolean checkHistory()
	{
		boolean res = super.checkHistory();
		return res;
	}
	//Display User Information
	public void userProperties()
	{
		super.showInfo();
	}
	public static void main(String[] args)
	{
		
		int choice=0;
		Scanner sc = new Scanner(System.in);
		String name,number;
		int age;
		//Get User Information
		System.out.println("Enter User Information");
		System.out.println("Enter UserName");
		name = sc.next();
		System.out.println("Enter UserNUmber");
		number = sc.next();
		while(number.length()!=10)
		{
			System.out.println("Invalid UserNUmber");
			System.out.println("Please enter correct UserNUmber");
			number = sc.next();
		}
		System.out.println("Enter Age");
		age = sc.nextInt();
		//Creating telephone object
		Telephone t = new Telephone(name,number,age);
		while(choice!=5)
		{
			System.out.println("Menu:\n1) Call\n2) Check Call History\n3) User Properties\n4) Receive\n5) Exit");
			choice = sc.nextInt();
			switch(choice)
			{
			case 1:
				//Make a call
				t.call();
				break;
			case 2:
				//Check Call History
				t.checkHistory();
				break;
			case 3:
				//Check User Properties
				t.userProperties();
				break;
			case 4:
				t.receive();
				break;
			case 5:
				return;
			}
		}
	}
}