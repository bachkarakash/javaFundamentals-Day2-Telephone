package telephone;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

class User
{
	String name,number;
	int age;
	Map<String, String> history= new HashMap<String, String>();
	User(String name,String number,int age)
	{
		this.name=name;
		this.number=number;
		this.age=age;
	}
	//Show User Properties
	public void showInfo()
	{
		System.out.println("name\tnumber\t\tage");
		System.out.println(this.name+"\t"+this.number+"\t"+this.age);
	}
	//Update Call History
	public void updateHistory(String keypad)
	{
		Date date = new Date();
		String callTime = date.toString();
		//If number is absent in history make a new entry
		if(!history.containsKey(keypad))
			history.put(keypad, callTime);
		//If number is already present then replace the timestamp
		else
			{
				history.replace(keypad, callTime);
			}
	}
	//Check call history
	public boolean checkHistory()
	{
		if(history.isEmpty())
		{
			System.out.println("No call history");
			return false;
		}
		System.out.println("Number\t\tTime");
		Iterator it = history.entrySet().iterator();
		while(it.hasNext())
		{
			Map.Entry m = (Map.Entry)it.next();
			System.out.println(m.getKey()+"\t"+m.getValue());
		}
		return true;
	}
}